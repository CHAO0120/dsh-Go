# 2622 精确 NOPINS 候选：非作者 SOURCE / APPLY / TEST-DESIGN 独审

## 结论与范围

**PASS_SCOPED，仅限下列精确 FULL-NOPINS、TESTONLY 的源码因果、实际 Git 源码应用及测试设计。** 未发现该范围内尚未解决的阻断。不继承旧 DESIGN_ONLY，不把此前两轮夹具 BLOCKED 改为历史通过；不是动态 A/B、实际 pins、完整 Host/App/Web 或设备验证。

固定基底 **e5d931cd84c21e833cf1f9dcbed6061008168f5e，runtime 0.2.2-rc.1**。我另建三个自有 unborn Git 源码投影，完成 **39次Git全部退出0、33项比较全部通过**：外层 TESTONLY/FULL 正反应用及完整raw再生；官方原文先应用旧Unicode再应用本inner、实际反向还原。投影没有完整上游目录和HEAD，不写成完整e5d checkout。作者冻结原件均保持原字节。[1]

**Node（含语法/import）、npm、rtbuild、测试、Host、模型、App/Web、设备及assemble均NOT_RUN。** 当前没有新pin，严格补丁器会拒绝缺失的新key，不可直接合并或部署。本报告不授予后续执行权限；实际record/strict、动态回执及含实录pin的新raw需要另审。

R=`/dev/shm/dshgo-core20-work`，O=`/workspace/scratch/dd836dce4665/core20`。本次只读取真实源、计算文件/JSON/TAR身份并执行自编数据程序与明确的Git源码操作；没有执行作者脚本、收到脚本或包代码。

## 1. 精确绑定

以下文件均在 `R/runtime/2622/`。

| 原件 | 字节 | SHA256 |
|---|---:|---|
| FULL-NOPINS raw | 17081 | `df7ca1546f2644a77f3e9c5e71d4cd6e0203106025ad7aca50a22b989b59869e` |
| TESTONLY raw | 11519 | `3469bebc86721311d45a26ea8dfa41b16bfe304badcd64f10985a367e7d48d84` |
| `inner/zzzzzzzzzzzzzzzzzzzzzz-turn-outline-first-human.diff` | 4098 | `05fb1b92472d7edc397e7dedff3d47f5f8521269dc592f659a54ca24c1795b0b` |
| `README.md` | 3587 | `9b8727efcf05c83aa53df6454a7fe839126c11764769dfc940baba4fcad6c8c4` |
| `source-proof.md` | 16178 | `81d6a08c192ba91c5f77ec1ad08ccbcc703fe478cd1779ea9c8fbf87044c9cbd` |
| `source-identities.json` | 28569 | `628facef11d8cebbc04b48b9ffada1c036206880fd42b4019ce9955343726dd3` |
| `author-freeze.json` | 2399 | `f4ce868f297d497db85759a109dc9eb39f413b43c50eac42ba811ff606010fd3` |

raw文件全名分别为 `2622-turn-outline-first-human-FULL-NOPINS-LF.patch` 与 `2622-turn-outline-first-human-TESTONLY-LF.patch`。两raw、两生产全文、197行新测试、旧Unicode九案及最终中文README/proof均已全文读；批量显示截断处补读完成，不以截断输出冒称全文。

FULL仓库层恰三路径：新inner、新 `runtime/tests/turn-outline-first-human.test.mjs`、既有 `runtime/tests/turn-outline-unicode.test.mjs`。最后一项仅恢复后的版本预期3→4。TESTONLY只含新测试，不提前改A的旧Unicode断言。两新路径在完整固定tree中不存在，mode均100644。依赖锁、pins、Dart、前端实现、布局、资源及动效未改。[2]

## 2. 固定源、顺序与实际应用

完整官方e5d tree为1606030 B / `db862e31627dc2749d5e4463d480fad551422aa8bc757be9bbb1d42fbbce45b5`，truncated=false。本次独立重新核固定输入的blob/mode，包含当前AGENTS、贡献/架构文、build-runtime、rtbuild、lock/pins、旧Unicode片与九案、v2 checkpoint及PNG。没有把3a91同路径自动当当前源；当前AGENTS为6900 B / `78a8b9878109c9cce65c2528eeefdd039465bcb2c27cb4ad54172e5f743a328a`。[2]

outline官方归档14395 B / `ffa7de197389f593311bd78158621519efd11aa0c8c21b7f815c12c5fa1bfa6f`，本次以**整个归档SHA512**重新核当前lock SRI，再比较其中index/types/package/LICENSE四成员与真实缓存，全部相等。使用已取得官方原件，没有重新下载或安装。pristine index为5775 B / `724f09b4c13de7cfb2b0a5ed5ccf776217e9e7d08ec6f458be8784e65069d78a`；真实应用旧Unicode后才得到本片前像。[1][2]

| npm目标（均在`@deepseek-ai/dsh-session-turn-outline/lib/`） | 本片前像 | 本片后像 |
|---|---|---|
| index.js | 6088 B / `8df29b7ad951745340ec6d9a8af4abc77bc9b9a3d570ce4e5b0dba30e60f0e7b` | 6358 B / `2a6a0d9df0d403d29bac5e9d35f7d36548577c1189d18c52437013f4a43f27a9` |
| types/types.d.ts | 2175 B / `79d16b1eddadde75e1680e61364b16043086d11989ee4473e3f5e1490f8e15` | 2373 B / `9c131aebc460fc639ec669c43a823802dd1adb4885d75e35986cf145664672e0` |

types前后均无尾LF，实际应用与反向后全文相等。以上是源码身份，**不是rtbuild实录pin**。

独立从tree取120个diff名，与当前pins全部key的集合及排序相同；直接读现行rtbuild的sorted规则。旧21z Unicode第88项；新22z first-human加入后第90项，中间是22z context-summary。index只有旧Unicode一条pin，types没有旧pin；没有漏掉已知后继修改。原rc.1为170个patch-target、89个末态target；只实录本片两目标的**预期**为121片/172条/90target，必须将来以真实record/strict和完整typed JSON核验。[2]

我独立实际Git的分组如下；不是执行产品测试的A/B：

| 自有源投影 | Git数 | 已实际完成 |
|---|---:|---|
| outer-A | 13 | 原pins/旧测试入索引；TESTONLY check/apply；默认空白门；完整raw重生；实际reverse；清除自身add-N后核空diff及原索引 |
| outer-B | 14 | FULL check/apply；两JS默认空白门、精确inner窄门；三全文及raw重生相等；实际reverse、清add-N并核原索引 |
| inner | 12 | 官方两原文→旧Unicode真实check/apply→核当前前像；本inner check/apply/默认目标空白门/全文重生；实际reverse回当前前像 |

全部39条使用 `git -c core.autocrlf=false`，没有commit、fetch、push或修改上游工作树。作者另外46Git/38比较的原记录已核，但不借它替代自己的实际动作。[1]

唯一非空stderr是我第18条FULL实际apply的**41条space before tab**，退出仍0：它们是新增inner文件中unified context前缀空格加原JS tab。我逐行分类41条，均在hunk内为合法context；原stderr及5条显示/其余36条计数保全。只对精确inner路径使用 `core.whitespace=-space-before-tab`；两测试与真实npm index/types保持默认diff-check。没有全仓关闭空白门或修改raw去追绿。作者第38条对应警告亦完整保留。[1][2]

## 3. 真实因果、最小状态与兼容

上游合同以第一条人类消息确定本轮预览；无文字图片保持空预览，后续steer不覆盖首提示。旧fold把 `last.prompt !== ''` 当作是否已见首提示；第一次图片preview为空时直接返回原state。于是“boundary后尚无人类消息”和“已提交无文字首图”两个历史可以具有同一旧state，下一条文字却应分别接纳/忽略。原seq是轮次锚点，draft/response是响应，不能无损代替这个区别。新增持久boolean有明确的信息需求。[3]

正常producer已核到当前App Composer允许图片加空文本、当前ChatScreen/ChatState调用、SDK非空才生成text block、API图片准入和同turn steer、当前AgentLoop next-step消费后真实user/message append。前提是首图能力/准入成功且已提交，后续文字也在同一turn成功提交；拒收、fallback为文字路径、过滤、发送失败或换轮不满足见证。没有模型运行、自然发生率或设备测量。[3]

consumer是官方Web turn rail，有至少两轮、内容宽度>900px等既有条件。未加载轮次采用投影；已加载纯图片首节点的本地preview为空也可能回落到投影。结论限装饰性预览归属，不是历史丢失、会话标题错误或手机原生窄屏已显示错误。App在这里是已核producer，本片不改Dart/Web显示策略。[3]

有限去重已全文读当前Unicode片和九案，以及取得的历史相关材料；旧片是完整码点/预算/多块/旧缓存，不覆盖本次图首消息后文字覆盖。不声称未取得的全部历史不存在同题。

全部生产出口逐一核：init/真正新turn置false；重复或更小boundary不重开；非user来源不占位；无turn不变；第一条人类消息无论preview空否均置true；后继人类消息不覆盖。空preview保留turns数组引用。assistant draft、turn/end的所有新state都保留该位；原响应选择、50/120预算、Unicode截断、seq锚点、wire四字段与summary=false未变。[4]

stateVersion3→4及公开TurnOutlineState同步必要：旧空prompt不能可靠猜false。当前registry版本失配时不服务旧row，restoreFloor回0，再从完整事件重新fold。新required字段未进入TurnOutlineEntry/wire。无完整日志时不承诺可恢复，也未测磁盘载入/重放成本。旧Unicode测试的实际v2 fixture不动，仅恢复结果版本断言改4。[4]

## 4. 精确测试设计及源码预测

197行新测试11015 B / `a9b52252aaf0564b515fc997b261b1c3e8097743547ce902510b3b0f1c882fe9`，通过公开构造器注册真实Cordis、SessionStore、Projection及outline。LLM包仅构造合法消息/stream；没有provider或模型调用。Session.append返回的真实冻结事件进入TRACE，未手写seq/time envelope、读私有日志或复制fold。图片引用来自仓库既有69 B/1×1 PNG的完整hash/元数据；这是投影API的合法输入形状，不是AttachmentStore保存、图像解码、完整App上传或模型准入测试。[4][5]

| 新案 | 首个语义oracle | A旧源预测 | B候选预测 |
|---|---|---|---|
| R1: first image-only human prompt stays empty after same-turn steer | 第139行完整wire entry的空prompt/空response | 后续文字被误当首提示，指定deepEqual红 | 通过，随后response/feed控制亦应通过 |
| R2: synthetic version3 checkpoint is rejected and full public log replays | 第165行viewCheckpoint应为{} | v3行被直接服务，指定deepEqual红 | 拒服、floor0、完整事件重放v4 |
| C1: text prompt, new turn and current checkpoint round trip preserve outline | 普通文本/context/当前checkpoint/新turn | 绿 | 绿 |

这只是源码预测，**未运行**。A仅新三案、恰两指定红一绿；B新三案加旧Unicode九案应为12绿。TESTONLY不包含旧Unicode版本调整，不能误把A安排成新三加旧九。原九案的唯一版本数字修改已逐字验证。

R1在turn/start之前订阅，boundary真正建立raw-view基线后，才断言私有位/assistant draft/重复boundary/steer不会额外推wire。晚订阅或restore后第一次baseline发布不在安静性保证内。重复boundary是上游明确合同控制，不冒称实际App一定重发。

R2的v3 row明确是SOURCE-derived人工schema-valid输入；seq/anchor来自实际append，且与本次public checkpoint分栏。不是历史磁盘/崩溃实录，B也不依赖A产物。断言公共view拒服和恢复结果，有实际可见语义，不直接检查私有boolean。

## 5. 准备可达性、真实归属及清理观察

两轮静态阻断都保留。v1只catch dispose拒绝，但当前Cordis `_unload`会容纳disposer错误并logger.error，dispose可resolve，因此空数组不能据此涵盖内部卸载错误。中间v2在无inject的owner直接读ctx.sessions/ctx.sessionProjections，真实getter仅查本fiber及祖先，不向子服务查，会先在准备阶段失败。当前版本分别以公开外层exporter与公开ctx.get窄修；旧原文及BLOCKED记录没有覆盖。[5]

我对当前真实源复核：`ctx.get(name)`不要求inject，默认检查provider活跃，并getTraceable到调用ctx；SessionStore.create和registry.onChanged据该调用ctx登记effect。因而三产品插件、Session及订阅属于子owner，父Context只持观察设施。没有测试访问私有Map或伪造服务实例。[5]

`t.after`在任何setup await前注册；外层exporter先于产品setup登记。所有structured warn/error，无论参数是Error还是字符串，都进入loggerMessages和fixtureFailures；没有按closing或预期A红豁免。清理依次尝试每个unsubscribe、await owner.dispose、移除exporter、outer.dispose，然后才输出唯一TRACE及显式检查。每阶段异常记录，不跳过后续清理。Cordis子unload已捕获而同步写出的错误，在owner.dispose完成之前仍由活着的父exporter观察；显式reject也记录。onChanged当前同步disposer只注销Set项，虽然返回值被void，未见本夹具因此遗漏异步清理的实际路径。[5]

范围必须保留：exporter移除后的外层框架内部日志、任意迟到异步observer不在观察区间；outer显式reject仍收集。这里没有新增timer、模型或Host工作，不可扩大为所有框架/进程日志无错。旧Unicode九案也没有这三个新案的TRACE/外层exporter，不能把12案都写成同样的清理观测覆盖。

Node已红test可能不另报after错误，所以未来新三案必须逐案有**唯一完整TURN_OUTLINE_TRACE**、case准确、fixtureFailures为显式空数组；当前collector会把观察到的warn/error一并记失败，loggerMessages也应核为空。只看两处A红且无第二条错误不够。缺TRACE、准备/import、超时、未知断言或清理失败不能充指定语义红。当前没有做这些动态判定。

## 6. 实际证据、发布与剩余限度

本次实际数据核验83项通过，包含所有声明来源字节、固定tree、整个归档SRI、前后源码、旧pin链、真正patch顺序及旧Unicode唯一改动。另核作者46条及自己39条的stdout/stderr文件身份，作者freeze八项全部匹配；实际39Git/33比较证据独立于作者记录。没有把“Git全0”等同Node能导入或测试能过。

准确保留准备史：作者来源定位曾发生FileNotFound/rg退出2，早期logger身份写入ENOSPC，夹具经历两次源级阻断；最终文件已修订冻结，原史未抹去。本审若干长工具调用在消息到达时被标为aborted before dispatch，未执行；没有把它们算Git或产品失败。实际本轮源码脚本执行仅一次，39Git全部0，原834B警告流保全。没有运行收到脚本或重做产品以追绿。

现行rtbuild严格模式在新key没有pin时明确停止；不能据Git匹配捏造记录。未来只能在另获授权的真实prefix中record/strict后，核本片两目标及所有旧pin类型/值，再生成含实录pin的新raw重新签。当前内容没有写版本号，但build-runtime把patches和构建配方纳入输入hash，**会改变runtimeVersion**；未assemble，没有实际新版本值。[6]

中文README的模拟清单和真实消费清单均是待执行项，不是已完成测量。自然图片/steer交错、Web实际显示、缓存持久化重放、设备及发生频率全部NOT_RUN。正式含pin交付、完整验证与回滚均仍按各自精确身份处理，本NOPINS签署不可自动沿用。

## 7. 独立记录与直接来源

| 独立记录（均在R/reviews/） | 字节 | SHA256 |
|---|---:|---|
| `2622-reviewer-source-apply.json` | 54209 | `fd2a7910124d83b6aa0cc44c7288ce0ef48b5ed2b7cd0d19622e89c1ab3524e1` |
| `2622-reviewer-source-identity-checks.json` | 40257 | `29c344fe793ae4afd693d18dc24a2bc07061acaacf6fdc4e6dec9c4c4b806b8b` |
| `2622-reviewer-final-bindings.json` | 13243 | `d26f89fba42a6df9350af071c0ec84891319ac2808b81f5331dcc2e429c83241` |

[1] 自编数据/Git脚本`R/reviews/2622-reviewer-git-source-apply.py`、上表实际记录、`2622-reviewer-git-logs/`及三份raw再生原文。作者脚本未执行；其54810B记录`7443e6b6ae5c0c6c5e69df8045821e98acc575c0fa8bd89545d4435a68cb03c6`仅只读核对。  
[2] `R/runtime/2622/source-identities.json`、官方原tar、当前tree/lock/pins及本审83项记录；全路径/身份均保在JSON，不用省略SHA作为唯一绑定。  
[3] `R/reviews/turn-outline-source-counterreview-SOURCE_ONLY.md`10955B/`228562012f0bafa9bc3adbb66dc45d5a4b5e34533aa8aab67ccbff4dcee2c535`；`R/runtime/turn-outline-source/`的真实producer-consumer/SDK/附件/ui-chat绑定与官方README。该既有独立源链只支撑条件因果，不代本次raw应用。  
[4] 本候选两真实生产全文、新197行测试及旧九案；`O/runtime/goal-consumer-source/patched/node_modules/@deepseek-ai/dsh-session-projection/lib/index.js`的snapshot/checkpoint/restoreFloor/viewCheckpoint/restore/drive；当前LLM真实createUser/Assistant/StreamAccumulator；当前Session的append返回合同。  
[5] `O/history/native-dedup/2311/sources/2307/cordis.js`的traceable/get/effect/_unload/await/logger.exporter；`R/runtime/phone-caller-source/effective/node_modules/@deepseek-ai/dsh-session/lib/index.js`的create/append/contained observers；registry.onChanged。当前Source身份与旧阻断/修订记录见`fixture-logger-source-binding-v2.json`及本审final-bindings。前次v2审11373B/`02b6620b2165a031f0879191059c277040a5bf1c12f099adb2f6df8877a604b1`仍仅DESIGN_ONLY。  
[6] 当前e5d已核blob的`runtime/lib/rtbuild.py:260–394`及`runtime/build-runtime.sh:398–409`，直接读取，未执行或抽取为替身产品。

**签署：仅精确SHA绑定的SOURCE / APPLY / TEST-DESIGN PASS_SCOPED；动态、实录pin与实际消费不在本签署内。**
