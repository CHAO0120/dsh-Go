# 2622：保留无文字首人类消息的轮次预览归属

**SOURCE_ONLY / NOPINS 候选，尚不可直接合并。** 固定基底 `e5d931cd84c21e833cf1f9dcbed6061008168f5e`，runtime `0.2.2-rc.1`，不叠其他 core20 产品。Refs：尚无已确认对应 issue；本片来自真实默认调用链的源码审查。

**问题与改动。** 合法图片首消息没有文字，且同一 turn 随后真正接纳文字 steer 时，旧 turnOutline 会把后者当首提示。影响限官方 Web turn rail 的装饰性预览，未证原生 App 显示错误或自然发生频率。补丁增加持久 `promptSeen` 位，首个人类消息即占位；空预览保留 turns 引用，真正新轮清位，响应分支保位。状态版本升为4并同步类型，旧缓存按现有规则从完整日志重放。wire 字段、Unicode预算、锚点及布局/资源/动效不改；没有 Dart 或前端实现改动。

**精确附件。** FULL 只含新 inner、新三案测试、旧 Unicode 测试的恢复版本预期3→4；TESTONLY只含新测试。两份均为真实 Git 生成的 LF/full-index/binary raw。

- `2622-turn-outline-first-human-FULL-NOPINS-LF.patch`：17081 B；SHA256 `df7ca1546f2644a77f3e9c5e71d4cd6e0203106025ad7aca50a22b989b59869e`。
- `2622-turn-outline-first-human-TESTONLY-LF.patch`：11519 B；SHA256 `3469bebc86721311d45a26ea8dfa41b16bfe304badcd64f10985a367e7d48d84`。

新 inner 为22个z前缀的 `turn-outline-first-human.diff`，在固定目录加入后的第90项，晚于第88项既有 Unicode 补丁。它只改 post-Unicode `index.js` 与尚无旧pin的 `types.d.ts`；类型文件无尾LF原样保留。完整目标身份与顺序见 source-proof/source-identities。

**已核与未核。** 作者5个全新 unborn 源码投影完成46次Git全0、38项数据比较通过，包括旧Unicode真实应用、inner及独立A/B源码树的正反应用、完整diff重生与全文比较；这不是完整上游HEAD，也不是A/B测试。FULL应用有41条嵌套diff合法context空白警告，原样保留，精确inner使用窄空白门。全部Node、语法/import、测试、Host、模型、App/Web与设备均NOT_RUN；非作者精确raw审查以另附报告为准，设计审不代签raw。

**待授权模拟清单。** A仅新3案：R1第139行空首预览、R2第165行旧v3缓存拒服为指定两红，C1绿；B新3案及旧Unicode9案应全绿。每个新案必须有唯一完整TRACE及空fixtureFailures，任何观察到的warn/error、准备或清理错误均阻断。图片引用是合法投影夹具，人工v3缓存明确非实录，不代表完整App/模型流程。没有在本地执行这些步骤。

**待真机/实际消费清单。** 用测试会话、可收图片的模型，先无文字发图，确认首消息已提交，再于同turn仍运行时正常追加文字；在同一引擎的官方Web可见turn rail条件下（至少两轮、内容宽度>900px）核该轮仍用轮次编号而非后续文字预览。再核普通文字首提示、新轮、Unicode边界及旧缓存重放。原生手机窄界面不作为该rail显示证据；图片拒收、提交失败或已换轮均不算复现。

**发布与回滚。** 新inner进入构建输入，**会改runtimeVersion；不手写版本，未assemble无实际新值**。pins保持基底原字节；须另行授权实际record/strict，核两个目标及所有旧pin不变，再形成含实录pin的最终raw并重新独审。源码候选可按自身raw反向恢复；若将来已有实录pin，只撤本片新增key，勿覆盖其他pins。设备与发布验证仍独立必要。
